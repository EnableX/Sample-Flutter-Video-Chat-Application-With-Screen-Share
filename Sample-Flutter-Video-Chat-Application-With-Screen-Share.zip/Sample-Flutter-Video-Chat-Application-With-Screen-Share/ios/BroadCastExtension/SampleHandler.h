//
//  SampleHandler.h
//  BroadCastExtension
//
//  Created by jaykumar on 15/12/21.
//

#import <ReplayKit/ReplayKit.h>

@interface SampleHandler : RPBroadcastSampleHandler

@end
